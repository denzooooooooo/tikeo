export class UpdateOrganizerDto {
  companyName?: string;
  description?: string;
  logo?: string;
  website?: string;
  facebookUrl?: string;
  twitterUrl?: string;
  instagramUrl?: string;
  linkedinUrl?: string;
}


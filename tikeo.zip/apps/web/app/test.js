export default function Test() {
  return <h1>TEST OK</h1>;
}
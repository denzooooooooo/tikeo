import type { Config } from 'tailwindcss';
declare const config: Config;
export default config;
//# sourceMappingURL=tailwind.config.d.ts.map
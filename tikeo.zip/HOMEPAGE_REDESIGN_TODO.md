# Homepage Redesign TODO

## Steps

- [x] 1. Create NearbyEventsSection.tsx (client component with hover video teaser)
- [x] 2. Update Navbar.tsx (search bar, better colors, mobile) + NavbarMobileMenu.tsx
- [x] 3. Update globals.css (new animations, scroll-reveal, cloud-drift, dark sections)
- [x] 4. Create HomeCategoriesSection.tsx
- [x] 5. Create HomeCountriesSection.tsx (dark background)
- [x] 6. Create HomeContestsSection.tsx (dark background)
- [x] 7. Create HomeFeaturesSection.tsx (dark red background)
- [x] 8. Create HomeBottomSections.tsx (Stats, HowItWorks, Organizers, CTA)
- [x] 9. Rewrite page.tsx (lean, imports all section components)

## All Done ✅
